"""Script entry point: python run_llmd_emu.py <router|gateway|worker|cluster> ... (same as python -m llmd_emu)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from llmd_emu.__main__ import main  # noqa: E402

if __name__ == "__main__":
    main()
