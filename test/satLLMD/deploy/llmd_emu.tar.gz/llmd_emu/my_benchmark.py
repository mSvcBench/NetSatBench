import json
import os
import threading
import time
import httpx
from llmd_emu.kvcache import PrefixKVCache, block_hashes, tokenize


LONG = " ".join(f"w{i}" for i in range(100))
BASE_URL = os.environ.get("EMU_BASE_URL", "http://localhost:8000")
DEFAULT_EMU_URL = f"{BASE_URL}/v1/chat/completions"

def chat(client, content, **kw):
    return client.post("/v1/chat/completions", json={"messages": [{"role": "user", "content": content}], **kw})

client = httpx.Client(base_url=BASE_URL, timeout=60.0)
def shared_test(prompt_length=1000, max_tokens=32, shared_prefix_length=100, n_requests=4, n_threads=1, thinking_time=0.1, start_shift=0.0, emu_url=DEFAULT_EMU_URL):
    
    # reset the server state
    # client.get("/reset")
    
    # Create a shared prefix
    shared_prefix = " ".join(f"ws{j}" for j in range(shared_prefix_length))
    residual_length = max(0, prompt_length - shared_prefix_length)
    responses = [[None for _ in range(n_threads)] for _ in range(n_requests)]

    def send(thread_id,n_requests,thinking_time=0.1):
        time.sleep(thread_id * start_shift)     # initial delay: thread i starts i * start_shift seconds late
        for n in range(n_requests):
            prompt = shared_prefix + " " + " ".join(f"w{thread_id}_{j}" for j in range(n * residual_length, (n + 1) * residual_length))
            response = client.post(emu_url, json={"messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens})
            responses[n][thread_id] = response.json()
            time.sleep(thinking_time)

    # Send the requests to the emulated server in parallel, one thread each
    threads = [threading.Thread(target=send, args=(i,n_requests,thinking_time)) for i in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # # Print the responses and their timing information
    # for n in range(n_requests):
    #     for t in range(n_threads):
    #         resp = responses[n][t]
    #         print(f"Request {n+1}, Thread {t+1}:")
    #         print(json.dumps(resp, indent=2))
    #         print("\n")

    # create a printed table with the timing information
    # (arrival is shown in seconds since the first request arrived at the gateway)
    arrivals = [r["llmd_emu"]["req_arrival_time"] for row in responses for r in row if r is not None]
    t0 = min(arrivals, default=0.0)
    cols = [("Request", 9), ("Thread", 8), ("Gateway", 14), ("Router", 13), ("Worker", 13), ("Arrival_s", 11), ("Prompt", 9), ("Cached", 9), ("Queue_s", 10), ("Prefill_s", 11),
            ("TTFT_s", 10), ("Decode_s", 10), ("E2E_s", 10)]
    fmt = "".join(f"{{:<{w}}}" for _, w in cols)
    header = fmt.format(*(name for name, _ in cols))
    print(header)
    print("-" * len(header))
    for n in range(n_requests):
        for t in range(n_threads):
            if responses[n][t] is None:
                print(fmt.format(n + 1, t + 1, *["N/A"] * (len(cols) - 2)))
                continue
            tm = responses[n][t]["llmd_emu"]                 # timings and pod
            usage = responses[n][t]["usage"]                # token counts
            print(fmt.format(n + 1, t + 1, tm["gateway"], tm["router"], tm["pod"], f"{tm['req_arrival_time'] - t0:.3f}", usage["prompt_tokens"],
                             usage["prompt_tokens_details"]["cached_tokens"], f"{tm['queue_s']:.4f}",
                             f"{tm['prefill_s']:.4f}", f"{tm['ttft_s']:.4f}", f"{tm['decode_s']:.4f}",
                             f"{tm['e2e_s']:.4f}"))

def __main__():
    # Run the random test with specified parameters
    shared_test(prompt_length=1000, max_tokens=100, shared_prefix_length=1000, n_requests=10, n_threads=3, thinking_time=0.1, start_shift=0.5)

if __name__ == "__main__":
    __main__()