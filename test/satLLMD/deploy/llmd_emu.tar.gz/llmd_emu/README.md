# llmd-emu

**A lightweight emulator of the [llm-d](https://llm-d.ai) serving pipeline.** The vLLM worker pods are replaced by a single process that tokenizes, prefills and decodes with a simple timing model and returns a dummy answer. Use it to test schedulers, gateways and clients without GPUs or a real vLLM pod.

```
client ──► gateway ──POST /pick──► router (scheduler)
              │                        ▲
              │                        │ /register, /debug/state
              └──POST /generate──► worker (vLLM-like pod) ×N
```

## Features

- **OpenAI-compatible API**: `/v1/chat/completions` and `/v1/completions`, streaming and non-streaming.
- **Realistic worker model**: a vLLM-style continuous-batching step scheduler with chunked prefill and a roofline step-time model, a KV-cache block pool with prefix caching, LRU eviction and slot-limited concurrency.
- **llm-d-style scheduler**: a separate router app with `prefix-aware`, `least-load` and `round-robin` policies and an approximate prefix index.
- **Per-request timing** (TTFT, E2E, cached tokens) in every response, plus Prometheus-style `/metrics`.
- **Time scaling**: run faster than real time while reported timings stay simulated.

## Quick start

Requires Python 3.14+.

```bash
pip install -r requirements.txt

# router :8100 + gateway :8000 + worker.replicas workers on :9000, :9001, ...
python -m llmd_emu cluster -c config.example.yaml

curl localhost:8000/v1/chat/completions -H 'content-type: application/json' \
  -d '{"messages":[{"role":"user","content":"hello"}],"max_tokens":16,"stream":true}'
```

To run each process by hand:

```bash
python -m llmd_emu router  -c config.example.yaml --port 8100
python -m llmd_emu gateway -c config.example.yaml --port 8000 --router-url http://127.0.0.1:8100
python -m llmd_emu worker  -c config.example.yaml --port 9000 --router-url http://127.0.0.1:8100
python -m llmd_emu worker  -c config.example.yaml --port 9001 --router-url http://127.0.0.1:8100
```

All roles bind to `::` by default (dual-stack: IPv4 and IPv6; falls back to `0.0.0.0` where the OS has no dual-stack). Pass `--host` to bind elsewhere. URLs with an IPv6 literal need brackets, e.g. `--router-url http://[::1]:8100`, `--url http://[::1]:9000`.

`python run_llmd_emu.py <role> ...` is equivalent to `python -m llmd_emu <role> ...`. Run the tests with `pytest -q tests`.

## Architecture

The emulator is three kinds of processes:

| Process | Role |
| --- | --- |
| **Gateway** | OpenAI-compatible front end. Asks the router where to send each request, forwards it to that worker and streams the reply back. |
| **Router** | The scheduler, a separate FastAPI app. It only picks a worker; it never touches request data. |
| **Worker** | A vLLM-like pod: tokenize, prefill and decode in one process (llm-d without P/D separation). Returns a dummy answer. |

Each worker registers its URL, KV pool size, block size and `slots` with the router on startup (retrying until the router is up), which is how the router learns the pool.

### Endpoints

| Process | Endpoints |
| --- | --- |
| Gateway | `/v1/chat/completions`, `/v1/completions`, `/v1/models`, `/health`, `/metrics`, `/debug/state` (gateway view plus each worker's real state), `POST /reset` (clears the approximate indexes and the workers' caches and counters; forwarded to the router) |
| Router | `POST /register`, `POST /deregister`, `POST /pick`, `POST /reset`, `/debug/state`, `/health` |
| Worker | `POST /generate` (NDJSON token stream, called by the gateway), `POST /reset`, `/debug/state` (includes `running_prefill` / `running_decode`), `/health` |

Errors: `400` the request can never fit in the KV pool, `503` no worker registered, `502` worker unreachable (the router drops it from the pool at the next refresh, until it registers again).

Every response carries per-request timing in `llmd_emu` and `usage.prompt_tokens_details.cached_tokens`. `llmd_emu` also names the agents that handled the request: `gateway`, `router` and `pod` (the worker). Each agent has a string id, set with `--name` (defaults `gateway-<port>`, `router-<port>`, `worker-<port>`; in `cluster` mode `worker-<i>`).

## Configuration

Settings live in a YAML file passed with `-c` (see [config.example.yaml](config.example.yaml)). Times are in seconds.

| Key | Meaning |
| --- | --- |
| `model`, `block_size`, `default_output_tokens`, `vocabulary`, `vocabulary_file`, `seed` | Model name, tokens per KV block, default `max_tokens`, word list the random answers are drawn from, optional RNG seed |
| `time_scale` | `> 1` runs faster than real time; reported timings stay simulated |
| `worker.replicas` | Number of workers started by `cluster` |
| `worker.slots` | Concurrent sequences per worker (held through prefill and decode; vLLM's `max-num-seqs`) |
| `worker.kv_cache_blocks` | KV pool size per worker, in blocks |
| `step.max_batched_tokens` | Token budget per step (decode tokens + prefill tokens); `null` = unlimited, i.e. no chunked prefill. Must be `>= worker.slots` |
| `step.base_s` | `s0`: minimum step time, streaming the weights once (memory-bound) |
| `step.compute_per_token_s` | `s_c`: matmul time per batched token, decode or prefill (compute-bound) |
| `step.per_kv_token_s` | `s_kv`: attention time per cached token read from the KV cache |
| `step.overhead_s` | Fixed per-step overhead (kernel launches, tensor-parallel all-reduce); default 0 |
| `trace.step_log` | `true` records one row per step for calibration (see [Step log](#step-log)) |
| `llm.*`, `hardware.*` | Informational: the model and GPU the `step` coefficients were derived from (not read by the emulator) |
| `router.policy` | `prefix-aware`, `least-load` or `round-robin` |
| `router.prefix_weight`, `router.load_weight` | Weights of the prefix-aware score |
| `router.refresh_interval_s` | How often the router re-reads each worker's real load (default 5) |

## Model

Tokens are words and punctuation (toy tokenizer). Let N = prompt tokens, C = cached tokens, M = output tokens, with `C = min(cached_blocks · block_size, N − 1)`: at least one prompt token is always computed.

### Step scheduler

Each worker runs one scheduler loop, like a vLLM engine with continuous batching. A sequence admitted to the worker (slot + KV blocks) joins the loop in the **prefill** phase with `N − C` tokens to compute, then switches to **decode**. Every pass of the loop is one forward step:

1. **Batch.** Every decoding sequence takes 1 token. The rest of the budget, `step.max_batched_tokens − n_d`, goes to prefilling sequences in admission order (FCFS). A long prompt is split over several steps (**chunked prefill**), so it does not stall the decodes.
2. **Step time.**

   ```
   T_step = max(s0, s_c · (n_d + n_p)) + s_kv · Σ L_i + t_ov
   ```

   `n_d` = decoding sequences, `n_p` = prefill tokens in the step, `L_i` = context length (tokens in the KV cache) of each sequence in the batch, `s0 / s_c / s_kv / t_ov` = `step.base_s / compute_per_token_s / per_kv_token_s / overhead_s`. The `max` is the weight GEMMs, memory-bound (streaming the weights, `s0`) for small batches and compute-bound (`s_c` per token) for large ones. The KV read is the attention kernel and does not overlap with them. Prefill sequences waiting for budget are not in the batch and add nothing.
3. **Advance.** After `T_step` (divided by `time_scale` in wall time), each decoding sequence emits one token. A prefilling sequence that finished its prompt in this step also emits its **first token**. Sequences with all `M` tokens emitted leave the loop and release their KV blocks.

The model is an ideal roofline: attention FLOPs, KV writes and kernel efficiencies are neglected, so latencies are lower bounds. Calibrate the coefficients against a real engine (see [Step log](#step-log)). The values in [config.example.yaml](config.example.yaml) are derived from datasheet values for Llama-3.1-70B (BF16) on 4× A100 80 GB with tensor parallelism 4.

**Latency.** TTFT = queueing (waiting for a slot and KV space) + time from joining the loop to the end of the last prefill step. Each later token takes one `T_step`, so the TPOT grows with the batch size and the total context on the worker. E2E = TTFT + the sum of the decode steps.

### Step log

With `trace.step_log: true` each worker records one row per step:

`(sim_time, n_decode, n_prefill, prefill_tokens, ctx_sum, step_s)`

`n_prefill` and `ctx_sum` count only the sequences in that step's batch. Fitting `step_s` against the other columns on measurements from a real engine gives the `step.*` coefficients.

### KV cache

Each worker has one pool of `worker.kv_cache_blocks` blocks.

- A running sequence pins `ceil((N+M)/block_size)` blocks and waits for space when the pool is full. Requests that can never fit return HTTP 400.
- Prompt blocks already pinned by a running sequence are shared by reference count and cost no new memory. Blocks that are only cached move from the cache to the sequence.
- The unpinned remainder is a prefix cache: a block-hash chain (`h_i = H(h_{i-1} ‖ block_i)`), so only true prefixes hit, with LRU eviction.
- A sequence's prompt blocks become shareable once its prefill is done. When it finishes, prompt and generated blocks go back into the cache, so multi-turn follow-ups reuse them.

Concurrency is limited by `worker.slots`, which produces queueing delay under load.

### Scheduling

The router does not see the workers' KV caches. For each worker it keeps an approximate index: an LRU of the same size as the worker's KV pool (`worker.kv_cache_blocks`, sent at registration) holding the block hashes of the prompts it routed there. The index can drift from the real cache (evictions, generated blocks), as in llm-d's approximate prefix scoring.

Policies (`router.policy`):

- `prefix-aware`: score = `router.prefix_weight · approx_cached_blocks − router.load_weight · inflight / slots`; the highest score wins.
- `least-load`: lowest `inflight / slots` (in-flight requests relative to the worker's slots).
- `round-robin`.

**In-flight tracking.** The router increments a worker's `inflight` on each pick. Every `router.refresh_interval_s` it reads each worker's `/debug/state` and rebases `inflight` on the worker's real count; an unreachable worker is dropped from the pool. Between refreshes the router does not see completions, so its view is stale on purpose, as with an endpoint picker scraping model-server metrics.

The gateway sends the raw prompt to the chosen worker, which tokenizes it itself.

## Project layout

| File | Contents |
| --- | --- |
| `llmd_emu/kvcache.py` | Hash chain, LRU, pinning |
| `llmd_emu/workers.py`, `worker_app.py` | Worker logic (step scheduler, KV reservation) and HTTP API |
| `llmd_emu/router.py`, `router_app.py` | Scheduler with approximate index, and router API |
| `llmd_emu/gateway.py`, `gateway_app.py` | Gateway pipeline (HTTP to router and workers) and API |
| `llmd_emu/config.py`, `errors.py` | Configuration and errors |
| `my_benchmark.py` | Example load generator with shared prefixes |
| `tests/` | Test suite |
