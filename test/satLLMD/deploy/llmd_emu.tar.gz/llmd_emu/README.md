# llmd-emu

**A lightweight emulator of the [llm-d](https://llm-d.ai) serving pipeline.** The vLLM worker pods are replaced by a single process that tokenizes, prefills and decodes with a simple timing model and returns a dummy answer. Use it to test schedulers, gateways and clients without GPUs or a real vLLM pod.

```
client ──► gateway ──POST /pick──► router (scheduler)
              │                        ▲
              │                        │ /register, /debug/state
              └──POST /generate──► worker (vLLM-like pod) ×N
```

## Features

- **OpenAI-compatible API**: `/v1/chat/completions` and `/v1/completions`, streaming and non-streaming.
- **Realistic worker model**: prefill and decode times, load-dependent slowdown, a KV-cache block pool with prefix caching, LRU eviction and slot-limited concurrency.
- **llm-d-style scheduler**: a separate router app with `prefix-aware`, `least-load` and `round-robin` policies and an approximate prefix index.
- **Per-request timing** (TTFT, E2E, cached tokens) in every response, plus Prometheus-style `/metrics`.
- **Time scaling**: run faster than real time while reported timings stay simulated.

## Quick start

Requires Python 3.14+.

```bash
pip install -r requirements.txt

# router :8100 + gateway :8000 + worker.replicas workers on :9000, :9001, ...
python -m llmd_emu cluster -c config.example.yaml

curl localhost:8000/v1/chat/completions -H 'content-type: application/json' \
  -d '{"messages":[{"role":"user","content":"hello"}],"max_tokens":16,"stream":true}'
```

To run each process by hand:

```bash
python -m llmd_emu router  -c config.example.yaml --port 8100
python -m llmd_emu gateway -c config.example.yaml --port 8000 --router-url http://127.0.0.1:8100
python -m llmd_emu worker  -c config.example.yaml --port 9000 --router-url http://127.0.0.1:8100
python -m llmd_emu worker  -c config.example.yaml --port 9001 --router-url http://127.0.0.1:8100
```

All roles bind to `::` by default (dual-stack: IPv4 and IPv6; falls back to `0.0.0.0` where the OS has no dual-stack). Pass `--host` to bind elsewhere. URLs with an IPv6 literal need brackets, e.g. `--router-url http://[::1]:8100`, `--url http://[::1]:9000`.

`python run_llmd_emu.py <role> ...` is equivalent to `python -m llmd_emu <role> ...`. Run the tests with `pytest -q tests`.

## Architecture

The emulator is three kinds of processes:

| Process | Role |
| --- | --- |
| **Gateway** | OpenAI-compatible front end. Asks the router where to send each request, forwards it to that worker and streams the reply back. |
| **Router** | The scheduler, a separate FastAPI app. It only picks a worker; it never touches request data. |
| **Worker** | A vLLM-like pod: tokenize, prefill and decode in one process (llm-d without P/D separation). Returns a dummy answer. |

Each worker registers its URL, KV pool size, block size and `slots` with the router on startup (retrying until the router is up), which is how the router learns the pool.

### Endpoints

| Process | Endpoints |
| --- | --- |
| Gateway | `/v1/chat/completions`, `/v1/completions`, `/v1/models`, `/health`, `/metrics`, `/debug/state` (gateway view plus each worker's real state), `POST /reset` (clears the approximate indexes and the workers' caches and counters; forwarded to the router) |
| Router | `POST /register`, `POST /deregister`, `POST /pick`, `POST /reset`, `/debug/state`, `/health` |
| Worker | `POST /generate` (NDJSON token stream, called by the gateway), `POST /reset`, `/debug/state`, `/health` |

Errors: `400` the request can never fit in the KV pool, `503` no worker registered, `502` worker unreachable (the router drops it from the pool at the next refresh, until it registers again).

Every response carries per-request timing in `llmd_emu` and `usage.prompt_tokens_details.cached_tokens`. `llmd_emu` also names the agents that handled the request: `gateway`, `router` and `pod` (the worker). Each agent has a string id, set with `--name` (defaults `gateway-<port>`, `router-<port>`, `worker-<port>`; in `cluster` mode `worker-<i>`).

## Configuration

Settings live in a YAML file passed with `-c` (see [config.example.yaml](config.example.yaml)). Times are in seconds.

| Key | Meaning |
| --- | --- |
| `model`, `block_size`, `default_output_tokens`, `vocabulary`, `vocabulary_file`, `seed` | Model name, tokens per KV block, default `max_tokens`, word list the random answers are drawn from, optional RNG seed |
| `time_scale` | `> 1` runs faster than real time; reported timings stay simulated |
| `worker.replicas` | Number of workers started by `cluster` |
| `worker.slots` | Concurrent sequences per worker (held through prefill and decode) |
| `worker.kv_cache_blocks` | KV pool size per worker, in blocks |
| `prefill.base_s`, `prefill.per_token_s`, `prefill.load_factor` | Prefill time model |
| `decode.ttft_s`, `decode.per_token_s`, `decode.load_factor` | Decode time model (`per_token_s` is the TPOT) |
| `router.policy` | `prefix-aware`, `least-load` or `round-robin` |
| `router.prefix_weight`, `router.load_weight` | Weights of the prefix-aware score |
| `router.refresh_interval_s` | How often the router re-reads each worker's real load (default 5) |

## Model

Tokens are words and punctuation (toy tokenizer). Let N = prompt tokens, C = cached tokens, M = output tokens, and R = the number of sequences running on the worker (admitted: slot + KV blocks) when a step starts.

- **Prefill**: `t_prefill = (prefill.base_s + (N − C) · prefill.per_token_s) · (1 + prefill.load_factor · (R − 1))`, with `C = min(cached_blocks · block_size, N − 1)`.
- **Decode**: `t_decode = decode.ttft_s + Σ step_i`, with `step_i = decode.per_token_s · (1 + decode.load_factor · (R − 1))`.
- **Latency**: TTFT = queueing + `t_prefill` + `decode.ttft_s` + first step. E2E = queueing + `t_prefill` + `t_decode`.

`R` is a cheap approximation of batching: more sequences means more KV to read and more compute per step. Prefill reads `R` once at its start; each decode token reads it again. A load factor of 0 disables the effect.

### KV cache

Each worker has one pool of `worker.kv_cache_blocks` blocks.

- A running sequence pins `ceil((N+M)/block_size)` blocks and waits for space when the pool is full. Requests that can never fit return HTTP 400.
- Prompt blocks already pinned by a running sequence are shared by reference count and cost no new memory. Blocks that are only cached move from the cache to the sequence.
- The unpinned remainder is a prefix cache: a block-hash chain (`h_i = H(h_{i-1} ‖ block_i)`), so only true prefixes hit, with LRU eviction.
- A sequence's prompt blocks become shareable once its prefill is done. When it finishes, prompt and generated blocks go back into the cache, so multi-turn follow-ups reuse them.

Concurrency is limited by `worker.slots`, which produces queueing delay under load.

### Scheduling

The router does not see the workers' KV caches. For each worker it keeps an approximate index: an LRU of the same size as the worker's KV pool (`worker.kv_cache_blocks`, sent at registration) holding the block hashes of the prompts it routed there. The index can drift from the real cache (evictions, generated blocks), as in llm-d's approximate prefix scoring.

Policies (`router.policy`):

- `prefix-aware`: score = `router.prefix_weight · approx_cached_blocks − router.load_weight · inflight / slots`; the highest score wins.
- `least-load`: lowest `inflight / slots` (in-flight requests relative to the worker's slots).
- `round-robin`.

**In-flight tracking.** The router increments a worker's `inflight` on each pick. Every `router.refresh_interval_s` it reads each worker's `/debug/state` and rebases `inflight` on the worker's real count; an unreachable worker is dropped from the pool. Between refreshes the router does not see completions, so its view is stale on purpose, as with an endpoint picker scraping model-server metrics.

The gateway sends the raw prompt to the chosen worker, which tokenizes it itself.

## Project layout

| File | Contents |
| --- | --- |
| `llmd_emu/kvcache.py` | Hash chain, LRU, pinning |
| `llmd_emu/workers.py`, `worker_app.py` | Worker logic and HTTP API |
| `llmd_emu/router.py`, `router_app.py` | Scheduler with approximate index, and router API |
| `llmd_emu/gateway.py`, `gateway_app.py` | Gateway pipeline (HTTP to router and workers) and API |
| `llmd_emu/config.py`, `errors.py` | Configuration and errors |
| `my_benchmark.py` | Example load generator with shared prefixes |
| `tests/` | Test suite |
