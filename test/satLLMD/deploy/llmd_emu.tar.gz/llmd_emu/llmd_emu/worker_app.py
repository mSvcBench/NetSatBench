"""HTTP front-end of one worker (a vLLM pod). The gateway reaches it here, like envoy reaches vLLM in llm-d."""
from __future__ import annotations

import asyncio
import contextlib
import json

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse

from .config import Config
from .errors import RequestTooLarge
from .workers import Worker


def create_worker_app(cfg: Config | None = None, name: str = "worker-0", url: str | None = None,
                      router_url: str | None = None, transport: httpx.AsyncBaseTransport | None = None,
                      verbose_answer: bool = False) -> FastAPI:
    """`verbose_answer`: also stream `info` (step time and, on the first token, the timings) with every token; by default
    the token lines carry only the token. The final `done` line with the request's timings is always sent. `url` is how the router and gateway reach this worker; with `router_url` set, the worker registers itself there on
    startup (retrying until the router is up) and deregisters on shutdown."""
    cfg = cfg or Config()
    worker = Worker(name, cfg)

    async def register_forever():
        async with httpx.AsyncClient(transport=transport, timeout=5) as client:
            while True:
                try:
                    worker.log.debug("registering at %s as %s", router_url, url)
                    (await client.post(f"{router_url}/register", json=worker.registration(url))).raise_for_status()
                    worker.log.debug("registered at %s", router_url)
                    return
                except httpx.HTTPError as e:
                    worker.log.debug("registration failed (%r), retrying in 1s", e)
                    await asyncio.sleep(1)

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        task = asyncio.create_task(register_forever()) if router_url else None
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, httpx.HTTPError):
                async with httpx.AsyncClient(transport=transport, timeout=2) as client:
                    worker.log.debug("deregistering from %s", router_url)
                    await client.post(f"{router_url}/deregister", json={"name": name})

    app = FastAPI(title=f"llm-d emulator worker {name}", lifespan=lifespan)
    app.state.worker = worker

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/debug/state")
    async def state():
        return worker.snapshot()

    @app.post("/reset")
    async def reset():
        worker.reset()
        return {"status": "ok"}

    @app.post("/generate")
    async def generate(req: Request):
        """Body: {"prompt": str, "n_out": int}. Streams NDJSON: one {"token"} line per generated token (in verbose-answer mode
        also "info": step_s, plus the timings on the first), then always a final line {"done": true, queue_s, prefill_s,
        decode_s, e2e_s, ttft_s, prompt_tokens, cached_tokens}."""
        body = await req.json()
        prompt, n_out = body.get("prompt"), body.get("n_out")
        if not isinstance(prompt, str) or not isinstance(n_out, int) or n_out < 1:
            raise HTTPException(422, "'prompt' (str) and 'n_out' (int >= 1) are required")
        gen = worker.run(prompt, n_out, body.get("req_id") or "-")
        try:
            first = await gen.__anext__()       # first generated token, fetched before the headers go out so errors map to HTTP 400
        except RequestTooLarge as e:
            raise HTTPException(400, str(e))

        def line(tok: str, info: dict) -> str:
            return json.dumps({"token": tok, "info": info} if verbose_answer else {"token": tok}) + "\n"

        async def stream():
            try:
                tok, info = first
                first_info = info
                queue_s, prefill_s, decode_s = info["queue_s"], info["prefill_s"], cfg.decode.ttft_s + info["step_s"]
                yield line(tok, info)
                async for tok, info in gen:
                    decode_s += info["step_s"]          # decode time as actually simulated (load-dependent)
                    yield line(tok, info)
                worker.log.debug("req=%s queue_s=%.6f prefill_s=%.6f decode_s=%.6f e2e_s=%.6f",
                                 body.get("req_id") or "-", queue_s, prefill_s, decode_s, queue_s + prefill_s + decode_s)
                yield json.dumps({"done": True, "queue_s": queue_s, "prefill_s": prefill_s, "decode_s": decode_s,
                                  "e2e_s": queue_s + prefill_s + decode_s, "ttft_s": first_info["ttft_s"],
                                  "prompt_tokens": first_info["prompt_tokens"],
                                  "cached_tokens": first_info["cached_tokens"]}) + "\n"
            finally:
                await gen.aclose()              # client gone mid-stream: unpin the sequence's blocks

        return StreamingResponse(stream(), media_type="application/x-ndjson")

    return app
