"""Block-based prefix KV cache (vLLM / llm-d style: hash-chained blocks, LRU eviction)."""
from __future__ import annotations

import hashlib
import re
from collections import OrderedDict

_TOKEN_RE = re.compile(r"\w+|[^\w\s]")


def tokenize(text: str) -> list[str]:
    """Toy tokenizer: words and punctuation marks are tokens."""
    return _TOKEN_RE.findall(text)


def prompt_tokens(text: str) -> list[str]:
    return tokenize(text) or ["<empty>"]


def block_hashes(tokens: list[str], block_size: int) -> list[str]:
    """Hash chain over *full* blocks: h_i = H(h_{i-1} || block_i).

    Two prompts share cached block i only if they share all of blocks 0..i (prefix property).
    """
    out, prev = [], ""
    for i in range(len(tokens) // block_size):
        blk = tokens[i * block_size:(i + 1) * block_size]
        prev = hashlib.blake2b((prev + "\x00" + "\x01".join(blk)).encode(), digest_size=8).hexdigest()
        out.append(prev)
    return out


class PrefixKVCache:
    """KV blocks in LRU order, keyed by content hash (running sequences also hold unhashed private blocks under
    unique keys). Each block has a pin count (running sequences using it); only unpinned blocks can be evicted."""

    def __init__(self, capacity_blocks: int):
        self.capacity = capacity_blocks
        self._blocks: OrderedDict[str, int] = OrderedDict()  # hash -> pin count; LRU: oldest first
        self._pinned = 0   # blocks with pin count > 0
        self.hits = 0      # blocks
        self.lookups = 0   # blocks
        self.evictions = 0

    def __len__(self) -> int:
        return len(self._blocks)

    def __contains__(self, h: str) -> bool:
        return h in self._blocks

    @property
    def pinned_blocks(self) -> int:
        return self._pinned

    def is_pinned(self, h: str) -> bool:
        return self._blocks.get(h, 0) > 0

    def lookup(self, hashes: list[str]) -> tuple[int, int]:
        """Longest resident prefix (in blocks) and how many of those blocks are pinned.
        Does not touch LRU state or stats."""
        n = n_pinned = 0
        for h in hashes:
            c = self._blocks.get(h)
            if c is None:
                break
            n += 1
            n_pinned += c > 0
        return n, n_pinned

    def peek(self, hashes: list[str]) -> int:
        return self.lookup(hashes)[0]

    def pin(self, h: str) -> None:
        """Add a pin to a block (inserting it if absent) and mark it most recently used."""
        c = self._blocks.get(h, 0)
        if c == 0:
            self._pinned += 1
        self._blocks[h] = c + 1
        self._blocks.move_to_end(h)

    def unpin(self, h: str) -> None:
        self._blocks[h] -= 1
        if self._blocks[h] == 0:
            self._pinned -= 1

    def record(self, hit_blocks: int, lookup_blocks: int) -> None:
        self.hits += hit_blocks
        self.lookups += lookup_blocks

    def drop(self, keys: list[str]) -> None:
        """Free pinned blocks that must not stay cached (e.g. a sequence's private blocks)."""
        for k in keys:
            if self._blocks.pop(k) > 0:
                self._pinned -= 1

    def promote(self, key: str, h: str) -> None:
        """A pinned private block now holds the content with hash `h`: re-key it so others can reuse it.
        If `h` is already cached (pinned by another sequence or not) the duplicate is freed and that block gets
        one more pin."""
        self.drop([key])
        self.pin(h)

    def insert(self, hashes: list[str]) -> None:
        """Add unpinned blocks (or refresh them), then evict LRU unpinned blocks down to capacity."""
        for h in hashes:
            if h in self._blocks:
                self._blocks.move_to_end(h)
            else:
                self._blocks[h] = 0 # value is the pin counter. 0 in this case
        self.evict()

    def evict(self) -> None:
        """Evict the oldest unpinned blocks until the cache fits its capacity (pinned blocks never go)."""
        excess = len(self._blocks) - self.capacity
        if excess <= 0:
            return
        victims = []
        for h, c in self._blocks.items():     # oldest first
            if c == 0:
                victims.append(h)
                if len(victims) == excess:
                    break
        for h in victims:
            del self._blocks[h]
        self.evictions += len(victims)

    def clear(self) -> None:
        """Drop all unpinned blocks and reset stats (pinned blocks belong to running sequences)."""
        for h in [h for h, c in self._blocks.items() if c == 0]:
            del self._blocks[h]
        self.hits = self.lookups = self.evictions = 0

    def stats(self) -> dict:
        return {
            "blocks_used": len(self._blocks),
            "pinned_blocks": self._pinned,
            "capacity_blocks": self.capacity,
            "hit_blocks": self.hits,
            "lookup_blocks": self.lookups,
            "hit_rate": (self.hits / self.lookups) if self.lookups else 0.0,
            "evictions": self.evictions,
        }
