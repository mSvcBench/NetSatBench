"""Emulated llm-d inference scheduler: picks a registered worker per request from its own, approximate view."""
from __future__ import annotations

import itertools
import logging
import math
from dataclasses import dataclass, field

from .config import Config
from .errors import NoWorkers
from .kvcache import PrefixKVCache, block_hashes, prompt_tokens

log = logging.getLogger("llmd_emu.router")


@dataclass
class WorkerHandle:
    """The router's view of one registered worker.

    `approx` is the approximate-prefix-cache index: an LRU of the same size as the worker's KV pool holding the
    block hashes of the prompts routed to it. The router never sees the worker's real cache (evictions, generated
    blocks), so this can drift from it, exactly like the llm-d scheduler's approximate prefix scoring.
    """
    name: str
    url: str
    kv_cache_blocks: int
    block_size: int
    slots: int
    approx: PrefixKVCache = field(init=False)
    inflight: int = 0          # estimate: worker's count at the last refresh + picks made since
    completed: int = 0         # as last reported by the worker

    def __post_init__(self):
        self.approx = PrefixKVCache(self.kv_cache_blocks)

    def fits(self, total_tokens: int) -> bool:
        return math.ceil(total_tokens / self.block_size) <= self.kv_cache_blocks


class Router:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.workers: dict[str, WorkerHandle] = {}      # the pool: filled by workers registering themselves
        self._rr = itertools.count()

    def register(self, name: str, url: str, kv_cache_blocks: int, block_size: int,
                 slots: int) -> WorkerHandle:
        w = self.workers[name] = WorkerHandle(name, url.rstrip("/"), kv_cache_blocks, block_size, slots)
        log.debug("register worker=%s url=%s kv_cache_blocks=%d block_size=%d slots=%d pool=%s",
                  name, w.url, kv_cache_blocks, block_size, slots, sorted(self.workers))
        return w

    def deregister(self, name: str) -> bool:
        removed = self.workers.pop(name, None) is not None
        log.debug("deregister worker=%s removed=%s pool=%s", name, removed, sorted(self.workers))
        return removed

    def reset(self) -> None:
        for w in self.workers.values():
            w.approx.clear()
            w.completed = 0

    def pick(self, prompt: str, n_out: int) -> tuple[WorkerHandle, list[str]]:
        """Return (worker, prompt block hashes). The router tokenizes on its own, as the scheduler does."""
        if not self.workers:
            raise NoWorkers("no worker registered")
        tokens = prompt_tokens(prompt)
        hashes = block_hashes(tokens, self.cfg.block_size)
        candidates = self._filter(len(tokens) + n_out)
        return self._scorer(candidates, hashes), hashes

    def _filter(self, total_tokens: int) -> list[WorkerHandle]:
        """Workers eligible for a request: those whose KV pool fits it, or the whole pool if none does."""
        pool = sorted(self.workers.values(), key=lambda w: w.name)
        return [w for w in pool if w.fits(total_tokens)] or pool

    def _scorer(self, candidates: list[WorkerHandle], hashes: list[str]) -> WorkerHandle:
        """Choose one of the (non-empty) candidates according to the configured scheduling policy."""
        r = self.cfg.router
        if r.policy == "round-robin":
            return candidates[next(self._rr) % len(candidates)]
        if r.policy == "least-load":
            return min(candidates, key=lambda w: w.inflight / w.slots)
        # prefix-aware: maximise  w_prefix * approx_cached_blocks - w_load * inflight / slots
        scored = [(r.prefix_weight * w.approx.peek(hashes) - r.load_weight * w.inflight / w.slots, -i, w)
                  for i, w in enumerate(candidates)]
        return max(scored, key=lambda s: s[:2])[2]
