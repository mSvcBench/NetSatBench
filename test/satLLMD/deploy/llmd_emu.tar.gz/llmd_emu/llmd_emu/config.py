"""Configuration for the llm-d emulator (all timing in seconds, sizes in bytes)."""
from __future__ import annotations

import os
from dataclasses import MISSING, dataclass, field, fields, is_dataclass
from typing import Any

import yaml


@dataclass
class WorkerConfig:
    replicas: int = 2
    slots: int = 8                    # max concurrent sequences per worker (held through prefill + decode)
    kv_cache_blocks: int = 2048       # KV pool (blocks): pinned by running sequences, the rest is prefix cache


@dataclass
class PrefillConfig:
    base_s: float = 0.005             # fixed overhead per prefill
    per_token_s: float = 0.0004       # t_prefill = base + uncached_tokens * per_token
    load_factor: float = 0.0          # prefill time *= 1 + load_factor * (other running sequences)


@dataclass
class DecodeConfig:
    ttft_s: float = 0.0               # extra latency before the first decoded token
    per_token_s: float = 0.02         # t_decode = n_out * per_token (TPOT)
    load_factor: float = 0.0          # each token's time *= 1 + load_factor * (other running sequences)


@dataclass
class RouterConfig:
    policy: str = "prefix-aware"      # prefix-aware | least-load | round-robin
    prefix_weight: float = 1.0        # score += weight * cached_blocks
    load_weight: float = 4.0          # score -= weight * (in-flight requests)
    refresh_interval_s: float = 5.0   # how often the router re-reads each worker's real load (inflight is rebased)


DEFAULT_VOCABULARY = (
    "the of and a to in is you that it he was for on are as with his they at be this from I have or by one had not "
    "but what all were when we there can an your which their said if do will each about how up out them then she "
    "many some so these would other into has more her two like him see time could no make than first been its who "
    "now people my made over did down only way find use may water long little very after words called just where "
    "most know satellite orbit storage signal ground station cache memory block token model prefill decode network"
).split()


@dataclass
class Config:
    model: str = "dummy-llm"
    block_size: int = 16              # tokens per KV block
    time_scale: float = 1.0           # >1 runs faster than "real" time (reported times stay simulated)
    default_output_tokens: int = 32
    vocabulary: list[str] = field(default_factory=lambda: list(DEFAULT_VOCABULARY))   # answers are random words drawn from it
    vocabulary_file: str | None = None  # word list file (one word per line, e.g. /usr/share/dict/words); overrides `vocabulary`
    seed: int | None = None           # seed for answer generation (None = non-deterministic)
    worker: WorkerConfig = field(default_factory=WorkerConfig)
    prefill: PrefillConfig = field(default_factory=PrefillConfig)
    decode: DecodeConfig = field(default_factory=DecodeConfig)
    router: RouterConfig = field(default_factory=RouterConfig)


def _build(cls, data: dict[str, Any] | None):
    data = data or {}
    kwargs = {}
    for f in fields(cls):
        if f.name not in data:
            continue
        sub = f.default_factory
        if sub is not MISSING and is_dataclass(sub):
            kwargs[f.name] = _build(sub, data[f.name])
        else:
            kwargs[f.name] = _coerce(f.type, data[f.name])
    return cls(**kwargs)


def _coerce(type_name: Any, value: Any) -> Any:
    # PyYAML (YAML 1.1) reads "12.5e9" as a string (needs "12.5e+9"), so convert numerics explicitly.
    if type_name == "float":
        return float(value)
    if type_name == "int":
        return int(float(value)) if isinstance(value, str) else value
    return value


def load_config(path: str | None) -> Config:
    if not path:
        return Config()
    with open(path) as fh:
        cfg = _build(Config, yaml.safe_load(fh))
    if cfg.vocabulary_file:
        # relative paths are resolved against the config file's directory
        vocab_path = os.path.join(os.path.dirname(os.path.abspath(path)), os.path.expanduser(cfg.vocabulary_file))
        with open(vocab_path) as fh:
            cfg.vocabulary = [w for w in fh.read().split() if w]
        if not cfg.vocabulary:
            raise ValueError(f"vocabulary_file {vocab_path} contains no words")
    return cfg
