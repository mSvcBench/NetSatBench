"""Emulated llm-d worker (a vLLM pod): prefill and decode in one process (no P/D separation, no KV transfer)."""
from __future__ import annotations

import asyncio
import itertools
import logging
import math
import random
from typing import AsyncIterator

from .config import Config
from .errors import RequestTooLarge
from .kvcache import PrefixKVCache, block_hashes, prompt_tokens as encode_prompt


async def sim_sleep(seconds: float, scale: float) -> None:
    if seconds > 0:
        await asyncio.sleep(seconds / scale)


class Worker:
    def __init__(self, name: str, cfg: Config):
        self.name, self.cfg = name, cfg
        self.log = logging.getLogger(f"llmd_emu.worker.{name}")
        self.capacity = cfg.worker.kv_cache_blocks
        # The whole KV pool is `cache`. A running sequence pins all its blocks until decode ends: reused prompt
        # blocks (shared by count, keyed by hash) and its own blocks (private keys, hashed once prefill is done).
        self._seq_ids = itertools.count()
        self.cache = PrefixKVCache(self.capacity)
        self._slots = asyncio.Semaphore(cfg.worker.slots)
        self._cond = asyncio.Condition()
        self.inflight = 0          # queued + running
        self.running = 0           # admitted sequences (slot + KV blocks), prefilling or decoding
        self.completed = 0
        self._rng = random.Random(cfg.seed)

    @property
    def pinned_blocks(self) -> int:
        return self.cache.pinned_blocks

    def registration(self, url: str) -> dict:
        """What the worker tells the gateway when it registers."""
        return {"name": self.name, "url": url, "kv_cache_blocks": self.capacity, "block_size": self.cfg.block_size,
                "slots": self.cfg.worker.slots}

    def snapshot(self) -> dict:
        return {"name": self.name, "inflight": self.inflight, "completed": self.completed,
                "running": self.running, "kv_pinned_blocks": self.pinned_blocks, "kv_capacity_blocks": self.capacity, **self.cache.stats()}

    def reset(self) -> None:
        # Prefix cache and counters only; running sequences keep their own pins/inflight accounting.
        self.cache.clear()
        self.completed = 0

    def blocks_for(self, total_tokens: int) -> int:
        return math.ceil(total_tokens / self.cfg.block_size)

    def fits(self, total_tokens: int) -> bool:
        return self.blocks_for(total_tokens) <= self.capacity

    async def _reserve(self, blocks: int, hashes: list[str]) -> tuple[list[str], list[str]]:
        """Admit a sequence of `blocks` blocks; returns (reused prompt hashes, keys of its new private blocks).

        Reused blocks cost no new memory if a running sequence already pins them; if they were only cached
        they get pinned (same memory, they just stop being evictable). The lookup runs once there is room and
        without awaiting afterwards, so the blocks to reuse can't be evicted between the check and the pinning.
        """
        async with self._cond:
            await self._cond.wait_for(
                lambda: self.pinned_blocks + blocks - self.cache.lookup(hashes)[1] <= self.capacity)
            reused, _ = self.cache.lookup(hashes)
            held = hashes[:reused]
            for h in held:
                self.cache.pin(h)
            self.cache.record(reused, len(hashes))
            sid = next(self._seq_ids)   # sequence (request) ID
            private = [f"~{sid}:{i}" for i in range(blocks - reused)]
            for k in private:
                self.cache.pin(k)               # k is a dummy string unique for the sequence used to merely occupy block in the cache, it will be promoted to a hash when the block is filled
            self.cache.evict()                  # evict unpinned blocks to make room
            return held, private

    def _share(self, hashes: list[str], held: list[str], private: list[str]) -> None:
        """`hashes` are the sequence's completed blocks. The ones not held yet are private blocks that now hold
        final content: they get their hash, so others can reuse them. If a concurrent sequence already holds that hash, our duplicate private block is freed and we share theirs."""
        n = len(held)
        for h, key in list(zip(hashes[n:], private)):   # copy: private shrinks below
            self.cache.promote(key, h)
            held.append(h)
            private.remove(key)

    async def _release(self, held: list[str], private: list[str]) -> None:
        """Decode over: unpin the sequence's blocks. Its private blocks are freed, its hashed blocks (prompt and
        completed generated blocks) stay cached, now evictable."""
        async with self._cond:
            for h in held:
                self.cache.unpin(h)
            self.cache.drop(private)
            self._cond.notify_all()

    def _slowdown(self, load_factor: float) -> float:
        """Cheap contention model: every other running sequence adds `load_factor` to the step time."""
        return 1.0 + load_factor * max(self.running - 1, 0)

    def make_answer(self, n: int) -> list[str]:
        """A random answer: `n` words drawn uniformly from the configured vocabulary."""
        vocab = self.cfg.vocabulary or ["ok"]
        return self._rng.choices(vocab, k=n)

    async def run(self, prompt: str, n_out: int, req_id: str = "-") -> AsyncIterator[tuple[str, dict]]:
        """Tokenize the prompt (the gateway forwards the raw text), prefill it, then generate `n_out` tokens, yielding one per TPOT.

        While running, the sequence pins all its blocks until decode ends. A block becomes shareable (hashed)
        as soon as it is full: the prompt's blocks after prefill, generated blocks as they fill. Hashed blocks
        stay cached (unpinned) afterwards, so follow-up turns can reuse the prompt and the answer.
        Prefill and decode steps slow down with the other sequences running on the worker (more KV to read, more
        compute): a step lasts `base * (1 + load_factor * (running - 1))`, with `running` read when the step starts.
        Yields (token, info); `info` has step_s (this token's simulated time) and, on the first token only,
        queue_s / prompt_tokens / cached_tokens / prefill_s / ttft_s.
        """
        c = self.cfg
        tokens = encode_prompt(prompt)
        prompt_tokens = len(tokens)
        if not self.fits(prompt_tokens + n_out):
            self.log.debug("req=%s rejected prompt_tokens=%d n_out=%d: exceeds KV capacity (%d blocks)",
                           req_id, prompt_tokens, n_out, self.capacity)
            raise RequestTooLarge(f"prompt+output ({prompt_tokens + n_out} tokens) exceeds KV capacity")
        answer = self.make_answer(n_out)
        # Generate the hash chain for the entire sequence (prompt + generated tokens)
        full_hashes = block_hashes(tokens + answer, c.block_size)   # hash chain of every block the sequence will fill in the cache
        hashes = full_hashes[:prompt_tokens // c.block_size]             # list of the prompt's full blocks that can be found in the cache 
        blocks = self.blocks_for(prompt_tokens + len(answer))            # total number of blocks the sequence will fill in the cache
        self.inflight += 1
        self.log.debug("req=%s received prompt_tokens=%d n_out=%d blocks=%d inflight=%d",
                       req_id, prompt_tokens, n_out, blocks, self.inflight)
        try:
            loop = asyncio.get_running_loop()
            t0 = loop.time()
            async with self._slots:                 # wait for a free sequence slot (n. of concurrent sequences admitted to the worker)
                held, private = await self._reserve(blocks, hashes)  # wait for KV pool space, reusing resident prefix blocks (held) and reserving new private blocks for the rest
                cached_blocks = len(held)
                self.running += 1
                try:
                    queue_s = (loop.time() - t0) * c.time_scale
                    # at least one token must be computed to produce the first logits
                    cached_tokens = min(cached_blocks * c.block_size, max(prompt_tokens - 1, 0))
                    prefill_s = c.prefill.base_s + (prompt_tokens - cached_tokens) * c.prefill.per_token_s
                    prefill_s *= self._slowdown(c.prefill.load_factor)
                    self.log.debug("req=%s admitted queue_s=%.6f running=%d cached_tokens=%d/%d pinned_blocks=%d",
                                   req_id, queue_s, self.running, cached_tokens, prompt_tokens, self.pinned_blocks)
                    await sim_sleep(prefill_s, c.time_scale)
                    self.log.debug("req=%s prefill_done prefill_s=%.6f", req_id, prefill_s)
                    self._share(hashes, held, private)       # prompt KV is now completely computed. private blocks are shared by hash with concurrent sequences, if any.
                    await sim_sleep(c.decode.ttft_s, c.time_scale) # simulate the time to compute the first token's logits (TTFT)
                    for i, tok in enumerate(answer):
                        step_s = c.decode.per_token_s * self._slowdown(c.decode.load_factor)
                        await sim_sleep(step_s, c.time_scale)
                        n_seq = prompt_tokens + i + 1           # tokens in the sequence so far
                        if n_seq % c.block_size == 0:           # a block just filled: hash it, others can share it
                            self._share(full_hashes[:n_seq // c.block_size], held, private)
                        info = {"step_s": step_s}
                        if i == 0:
                            info |= {"queue_s": queue_s, "prompt_tokens": prompt_tokens, "cached_tokens": cached_tokens,
                                     "prefill_s": prefill_s, "ttft_s": queue_s + prefill_s + c.decode.ttft_s + step_s}
                        yield tok, info
                finally:
                    self.running -= 1
                    await self._release(held, private)
                    self.log.debug("req=%s released running=%d pinned_blocks=%d", req_id, self.running, self.pinned_blocks)
            self.completed += 1
            self.log.debug("req=%s decode_done tokens=%d completed=%d", req_id, n_out, self.completed)
        finally:
            self.inflight -= 1
