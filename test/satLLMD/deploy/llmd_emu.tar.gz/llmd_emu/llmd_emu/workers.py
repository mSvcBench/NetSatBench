"""Emulated llm-d worker (a vLLM pod): prefill and decode in one process (no P/D separation, no KV transfer).

Latency model: one scheduler step loop per worker. At every step all decoding sequences emit one token and the
prefilling sequences share a token budget (decode has priority). The step lasts

    T_step = max(s0, s_c*(n_d + c)) + s_kv*sum(L_i) + t_ov

n_d decoding sequences, L_i context length of every running sequence, c prefill tokens in the step
(coefficients: cfg.step). The max is the weight GEMMs (streaming
s0 vs matmul compute s_c per token); the KV read is the attention kernel and does not overlap with them.
KV writes and attention FLOPs are neglected.
"""
from __future__ import annotations

import asyncio
import itertools
import logging
import math
import random
from typing import AsyncIterator

from .config import Config
from .errors import RequestTooLarge
from .kvcache import PrefixKVCache, block_hashes, prompt_tokens as encode_prompt


async def sim_sleep(seconds: float, scale: float) -> None:
    if seconds > 0:
        await asyncio.sleep(seconds / scale)


class _Seq:
    """Scheduler-side state of one admitted sequence."""
    __slots__ = ("remaining", "left", "ctx", "alloc", "phase", "q")

    def __init__(self, remaining: int, left: int, ctx: int):
        self.remaining = remaining   # uncached prompt tokens still to prefill (R_j)
        self.left = left             # output tokens still to emit
        self.ctx = ctx               # context length currently in the KV cache (L_i)
        self.alloc = 0               # prefill tokens granted in the current step
        self.phase = "prefill"       # "prefill" | "decode"
        self.q: asyncio.Queue = asyncio.Queue()   # events: (kind, step_s, sim_now), kind in first|tok|end


class Worker:
    def __init__(self, name: str, cfg: Config):
        self.name, self.cfg = name, cfg
        self.log = logging.getLogger(f"llmd_emu.worker.{name}")
        self.capacity = cfg.worker.kv_cache_blocks
        # The whole KV pool is `cache`. A running sequence pins all its blocks until decode ends: reused prompt
        # blocks (shared by count, keyed by hash) and its own blocks (private keys, hashed once prefill is done).
        self._seq_ids = itertools.count()
        self.cache = PrefixKVCache(self.capacity)
        self._slots = asyncio.Semaphore(cfg.worker.slots)
        self._cond = asyncio.Condition()
        self.inflight = 0          # queued + running
        self.running = 0           # admitted sequences (slot + KV blocks), prefilling or decoding
        self.completed = 0
        self._rng = random.Random(cfg.seed)
        # step scheduler state
        self._seqs: list[_Seq] = []          # admitted sequences in admission order (FCFS for the prefill budget)
        self._wake = asyncio.Event()         # set when a sequence is registered while the loop is idle
        self._loop_task: asyncio.Task | None = None
        self.sim_now = 0.0                   # simulated time spent in steps (s); independent of wall clock and time_scale
        trace = getattr(cfg, "trace", None)
        self.step_log: list | None = [] if getattr(trace, "step_log", False) else None
        # rows: (sim_now_after_step, n_decode, n_prefill, prefill_tokens, ctx_sum, step_s), for calibration by regression

    @property
    def n_decode(self) -> int:
        return sum(1 for s in self._seqs if s.phase == "decode")

    @property
    def n_prefill(self) -> int:
        return sum(1 for s in self._seqs if s.phase == "prefill")

    @property
    def pinned_blocks(self) -> int:
        return self.cache.pinned_blocks

    def registration(self, url: str) -> dict:
        """What the worker tells the gateway when it registers."""
        return {"name": self.name, "url": url, "kv_cache_blocks": self.capacity, "block_size": self.cfg.block_size,
                "slots": self.cfg.worker.slots}

    def snapshot(self) -> dict:
        return {"name": self.name, "inflight": self.inflight, "completed": self.completed,
                "running": self.running, "running_prefill": self.n_prefill, "running_decode": self.n_decode,
                "kv_pinned_blocks": self.pinned_blocks, "kv_capacity_blocks": self.capacity, **self.cache.stats()}

    def reset(self) -> None:
        # Prefix cache and counters only; running sequences keep their own pins/inflight accounting.
        self.cache.clear()
        self.completed = 0

    def blocks_for(self, total_tokens: int) -> int:
        return math.ceil(total_tokens / self.cfg.block_size)

    def fits(self, total_tokens: int) -> bool:
        return self.blocks_for(total_tokens) <= self.capacity

    async def _reserve(self, blocks: int, hashes: list[str]) -> tuple[list[str], list[str]]:
        """Admit a sequence of `blocks` blocks; returns (reused prompt hashes, keys of its new private blocks).

        Reused blocks cost no new memory if a running sequence already pins them; if they were only cached
        they get pinned (same memory, they just stop being evictable). The lookup runs once there is room and
        without awaiting afterwards, so the blocks to reuse can't be evicted between the check and the pinning.
        """
        async with self._cond:
            await self._cond.wait_for(
                lambda: self.pinned_blocks + blocks - self.cache.lookup(hashes)[1] <= self.capacity)
            reused, _ = self.cache.lookup(hashes)
            held = hashes[:reused]
            for h in held:
                self.cache.pin(h)
            self.cache.record(reused, len(hashes))
            sid = next(self._seq_ids)   # sequence (request) ID
            private = [f"~{sid}:{i}" for i in range(blocks - reused)]
            for k in private:
                self.cache.pin(k)               # k is a dummy string unique for the sequence used to merely occupy block in the cache, it will be promoted to a hash when the block is filled
            self.cache.evict()                  # evict unpinned blocks to make room
            return held, private

    def _share(self, hashes: list[str], held: list[str], private: list[str]) -> None:
        """`hashes` are the sequence's completed blocks. The ones not held yet are private blocks that now hold
        final content: they get their hash, so others can reuse them. If a concurrent sequence already holds that hash, our duplicate private block is freed and we share theirs."""
        n = len(held)
        for h, key in list(zip(hashes[n:], private)):   # copy: private shrinks below
            self.cache.promote(key, h)
            held.append(h)
            private.remove(key)

    async def _release(self, held: list[str], private: list[str]) -> None:
        """Decode over: unpin the sequence's blocks. Its private blocks are freed, its hashed blocks (prompt and
        completed generated blocks) stay cached, now evictable."""
        async with self._cond:
            for h in held:
                self.cache.unpin(h)
            self.cache.drop(private)
            self._cond.notify_all()

    def make_answer(self, n: int) -> list[str]:
        """A random answer: `n` words drawn uniformly from the configured vocabulary."""
        vocab = self.cfg.vocabulary or ["ok"]
        return self._rng.choices(vocab, k=n)

    # ------------------------------------------------------------------ step scheduler

    def _step_time(self, n_d: int, ctx_sum: int, n_p: int) -> float:
        """T_step = max(s0, s_c*(n_d + n_p)) + s_kv*sum(L_i) + t_ov (all coefficients from cfg.step)."""
        st = self.cfg.step
        weights = max(st.base_s, st.compute_per_token_s * (n_d + n_p))   # weight GEMMs: memory- vs compute-bound
        return weights + st.per_kv_token_s * ctx_sum + getattr(st, "overhead_s", 0.0)

    def _ensure_loop(self) -> None:
        if self._loop_task is None or self._loop_task.done():
            self._loop_task = asyncio.get_running_loop().create_task(self._step_loop())
            self._loop_task.add_done_callback(self._loop_done)

    def _loop_done(self, task: asyncio.Task) -> None:
        if not task.cancelled() and task.exception() is not None:
            self.log.error("step loop died", exc_info=task.exception())

    async def close(self) -> None:
        if self._loop_task is not None:
            self._loop_task.cancel()

    async def _step_loop(self) -> None:
        """One scheduler iteration per pass: build the batch, sleep T_step, then advance every sequence."""
        max_tokens = self.cfg.step.max_batched_tokens          # None = unlimited (no chunking)
        while True:
            if not self._seqs:
                self._wake.clear()
                await self._wake.wait()
                continue
            dec = [s for s in self._seqs if s.phase == "decode"]
            pre = [s for s in self._seqs if s.phase == "prefill"]
            prefill_budget = math.inf if max_tokens is None else max_tokens - len(dec)   # decode tokens come first
            prefill_tokens = 0
            for s in pre:                                      # FCFS in admission order
                take = min(s.remaining, prefill_budget - prefill_tokens)
                if take <= 0:
                    break
                s.alloc, prefill_tokens = take, prefill_tokens + take
            ctx_sum = sum(s.ctx for s in dec) + sum(s.ctx for s in pre if s.alloc)   # only sequences in this step's batch
            t = self._step_time(len(dec), ctx_sum, prefill_tokens)
            await sim_sleep(t, self.cfg.time_scale)
            self.sim_now += t
            now = self.sim_now
            if self.step_log is not None:
                n_pre = sum(1 for s in pre if s.alloc)         # prefill sequences in this step's batch
                self.step_log.append((now, len(dec), n_pre, prefill_tokens, ctx_sum, t))
            for s in dec:                                      # one token per decoding sequence
                s.left -= 1
                s.ctx += 1
                s.q.put_nowait(("tok", t, now))        # tell run() one more token is ready (step duration, sim time); run() yields answer[i]
            for s in pre:
                if s.alloc:
                    s.remaining -= s.alloc
                    s.ctx += s.alloc
                    s.alloc = 0
                    if s.remaining <= 0:                       # last prefill step: it also emits the first token
                        s.phase = "decode"
                        if s.left > 0:
                            s.left -= 1
                        s.q.put_nowait(("first", t, now))   # prefill done: run() records prefill_s/TTFT, shares prompt KV, yields answer[0] if n_out > 0
            done = [s for s in dec + pre if s.phase == "decode" and s.left <= 0]
            if done:
                self._seqs = [s for s in self._seqs if s not in done]
                for s in done:
                    s.q.put_nowait(("end", t, now))     # all output emitted: run() stops waiting and releases the sequence's KV blocks

    # ------------------------------------------------------------------ request path

    async def run(self, prompt: str, n_out: int, req_id: str = "-") -> AsyncIterator[tuple[str, dict]]:
        """Tokenize the prompt (the gateway forwards the raw text), prefill it, then generate `n_out` tokens.

        While running, the sequence pins all its blocks until decode ends. A block becomes shareable (hashed)
        as soon as it is full: the prompt's blocks after prefill, generated blocks as they fill. Hashed blocks
        stay cached (unpinned) afterwards, so follow-up turns can reuse the prompt and the answer.
        Timing comes from the worker's step loop (see module docstring): the sequence is registered with the
        scheduler and receives one event per step. The first token is emitted by the last prefill step.
        Yields (token, info); `info` has step_s (duration of the step that produced this token) and, on the first
        token only, queue_s / prompt_tokens / cached_tokens / prefill_s / ttft_s (ttft_s = queue_s + prefill_s,
        where prefill_s is the simulated time from registration to the end of the last prefill step).
        """
        c = self.cfg
        tokens = encode_prompt(prompt)
        prompt_tokens = len(tokens)
        if not self.fits(prompt_tokens + n_out):
            self.log.debug("req=%s rejected prompt_tokens=%d n_out=%d: exceeds KV capacity (%d blocks)",
                           req_id, prompt_tokens, n_out, self.capacity)
            raise RequestTooLarge(f"prompt+output ({prompt_tokens + n_out} tokens) exceeds KV capacity")
        answer = self.make_answer(n_out)
        # Generate the hash chain for the entire sequence (prompt + generated tokens)
        full_hashes = block_hashes(tokens + answer, c.block_size)   # hash chain of every block the sequence will fill in the cache
        hashes = full_hashes[:prompt_tokens // c.block_size]             # list of the prompt's full blocks that can be found in the cache
        blocks = self.blocks_for(prompt_tokens + len(answer))            # total number of blocks the sequence will fill in the cache
        self.inflight += 1
        self.log.debug("req=%s received prompt_tokens=%d n_out=%d blocks=%d inflight=%d",
                       req_id, prompt_tokens, n_out, blocks, self.inflight)
        try:
            loop = asyncio.get_running_loop()
            t0 = loop.time()
            async with self._slots:                 # wait for a free sequence slot (n. of concurrent sequences admitted to the worker)
                held, private = await self._reserve(blocks, hashes)  # wait for KV pool space, reusing resident prefix blocks (held) and reserving new private blocks for the rest
                cached_blocks = len(held)
                self.running += 1
                seq: _Seq | None = None
                try:
                    queue_s = (loop.time() - t0) * c.time_scale
                    # at least one token must be computed to produce the first logits
                    cached_tokens = min(cached_blocks * c.block_size, max(prompt_tokens - 1, 0))
                    self.log.debug("req=%s admitted queue_s=%.6f running=%d cached_tokens=%d/%d pinned_blocks=%d",
                                   req_id, queue_s, self.running, cached_tokens, prompt_tokens, self.pinned_blocks)
                    seq = _Seq(remaining=max(prompt_tokens - cached_tokens, 1), left=n_out, ctx=cached_tokens)
                    t_reg = self.sim_now
                    self._seqs.append(seq)                  # registered: the step loop now schedules it
                    self._ensure_loop()
                    self._wake.set()
                    prefill_s = 0.0
                    i = 0                                   # index of the next token to yield
                    while True:
                        kind, step_s, now = await seq.q.get()
                        if kind == "end":
                            break
                        if kind == "first":
                            prefill_s = now - t_reg
                            self.log.debug("req=%s prefill_done prefill_s=%.6f", req_id, prefill_s)
                            self._share(hashes, held, private)   # prompt KV is now completely computed. private blocks are shared by hash with concurrent sequences, if any.
                            if n_out == 0:
                                continue
                        n_seq = prompt_tokens + i + 1           # tokens in the sequence so far
                        if n_seq % c.block_size == 0:           # a block just filled: hash it, others can share it
                            self._share(full_hashes[:n_seq // c.block_size], held, private)
                        info = {"step_s": step_s}
                        if i == 0:
                            info |= {"queue_s": queue_s, "prompt_tokens": prompt_tokens, "cached_tokens": cached_tokens,
                                     "prefill_s": prefill_s, "ttft_s": queue_s + prefill_s}
                        yield answer[i], info
                        i += 1
                finally:
                    if seq is not None and seq in self._seqs:   # client gone before the sequence finished
                        self._seqs.remove(seq)
                    self.running -= 1
                    await self._release(held, private)
                    self.log.debug("req=%s released running=%d pinned_blocks=%d", req_id, self.running, self.pinned_blocks)
            self.completed += 1
            self.log.debug("req=%s decode_done tokens=%d completed=%d", req_id, n_out, self.completed)
        finally:
            self.inflight -= 1