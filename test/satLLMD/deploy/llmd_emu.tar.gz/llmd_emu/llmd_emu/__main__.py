import argparse
import logging
import os
import socket
import subprocess
import sys

import uvicorn

from .config import load_config
from .gateway_app import create_gateway_app
from .router_app import create_router_app
from .worker_app import create_worker_app


def _default_host() -> str:
    """Bind to every interface, IPv4 and IPv6: "::" is dual-stack where the OS supports it, else IPv4 only."""
    return "::" if socket.has_dualstack_ipv6() else "0.0.0.0"


def _local_url(host: str, port: int) -> str:
    """URL for reaching a service we bound to `host` from this machine (IPv6 literals need brackets)."""
    host = {"": "127.0.0.1", "0.0.0.0": "127.0.0.1", "::": "::1"}.get(host, host)
    return f"http://[{host}]:{port}" if ":" in host else f"http://{host}:{port}"


def _spawn_router(a) -> subprocess.Popen:
    entry = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "run_llmd_emu.py")
    cmd = [sys.executable, entry, "router", "--host", a.host, "--port", str(a.router_port),
           "--name", f"router-{a.router_port}", "--log-level", a.log_level]
    if a.config:
        cmd += ["-c", a.config]
    return subprocess.Popen(cmd)


def _spawn_workers(a, n: int) -> list[subprocess.Popen]:
    # Run the children through a script path, not `-m llmd_emu`: under debugpy (VS Code) module resolution in the
    # child process fails with "No module named llmd_emu", even with PYTHONPATH set.
    entry = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "run_llmd_emu.py")
    procs = []
    for i in range(n):
        cmd = [sys.executable, entry, "worker", "--host", a.host, "--port", str(a.worker_port + i),
               "--name", f"worker-{i}", "--router-url", _local_url(a.host, a.router_port)]
        if a.config:
            cmd += ["-c", a.config]
        cmd += ["--log-level", a.log_level]
        if a.verbose_answer:
            cmd.append("--verbose-answer")
        procs.append(subprocess.Popen(cmd))
    return procs


def _configure_logging(log_level: str) -> None:
    logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("llmd_emu").setLevel(log_level.upper())

    for logger_name, log_format in (
        ("llmd_emu.gateway", "🌐 %(asctime)s %(levelname)s GATEWAY: %(message)s"),
        ("llmd_emu.router", "🧭 %(asctime)s %(levelname)s ROUTER: %(message)s"),
        ("llmd_emu.worker", "⚙️ %(asctime)s %(levelname)s WORKER %(name)s: %(message)s"),
    ):
        role_logger = logging.getLogger(logger_name)
        role_logger.handlers.clear()
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(log_format))
        role_logger.addHandler(handler)
        role_logger.propagate = False


def main():
    ap = argparse.ArgumentParser(description="llm-d emulator")
    sub = ap.add_subparsers(dest="role", required=True)

    def common(p):
        p.add_argument("-c", "--config", help="YAML config file")
        p.add_argument("--host", default=_default_host(), help="bind address, IPv4 or IPv6 (default: all interfaces, dual-stack)")
        p.add_argument("--log-level", default="DEBUG", help="level of the llmd_emu loggers (default: DEBUG)")

    p = sub.add_parser("router", help="scheduler (own FastAPI app); workers register with it")
    common(p)
    p.add_argument("--port", type=int, default=8100)
    p.add_argument("--name", help="id reported in the responses (default: router-<port>)")

    p = sub.add_parser("gateway", help="OpenAI-compatible front-end; asks the router where to send each request")
    common(p)
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--name", help="id reported in the responses (default: gateway-<port>)")
    p.add_argument("--router-url", default="http://127.0.0.1:8100")

    p = sub.add_parser("worker", help="one vLLM-like pod; registers with the gateway")
    common(p)
    p.add_argument("--port", type=int, default=9000)
    p.add_argument("--name", help="id reported in the responses (default: worker-<port>)")
    p.add_argument("--router-url", default="http://127.0.0.1:8100")
    p.add_argument("--verbose-answer", action="store_true", help="workers also stream per-token info (step time, first-token timings); the final done line is always sent")
    p.add_argument("--url", help="URL the gateway uses to reach this worker (default: derived from --host and --port; give IPv6 literals in brackets, e.g. http://[::1]:9000)")

    p = sub.add_parser("cluster", help="router plus worker.replicas workers as subprocesses, gateway in this process")
    common(p)
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--router-port", type=int, default=8100)
    p.add_argument("--worker-port", type=int, default=9000, help="first worker port; the others follow")
    p.add_argument("--verbose-answer", action="store_true", help="workers also stream per-token info (step time, first-token timings); the final done line is always sent")

    a = ap.parse_args()
    _configure_logging(a.log_level)
    cfg = load_config(a.config)
    if a.role == "router":
        uvicorn.run(create_router_app(cfg, name=a.name or f"router-{a.port}"), host=a.host, port=a.port)
    elif a.role == "gateway":
        uvicorn.run(create_gateway_app(cfg, a.router_url, name=a.name or f"gateway-{a.port}"), host=a.host, port=a.port)
    elif a.role == "worker":
        name = a.name or f"worker-{a.port}"
        url = a.url or _local_url(a.host, a.port)
        uvicorn.run(create_worker_app(cfg, name, url, a.router_url, verbose_answer=a.verbose_answer), host=a.host, port=a.port)
    else:
        procs = [_spawn_router(a)] + _spawn_workers(a, cfg.worker.replicas)
        try:
            uvicorn.run(create_gateway_app(cfg, _local_url(a.host, a.router_port), name=f"gateway-{a.port}"), host=a.host, port=a.port)
        finally:
            for pr in procs:
                pr.terminate()
            for pr in procs:
                pr.wait()


if __name__ == "__main__":
    main()
