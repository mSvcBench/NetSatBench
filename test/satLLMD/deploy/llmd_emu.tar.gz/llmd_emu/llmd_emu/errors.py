"""Exceptions shared by the gateway and the workers."""


class RequestTooLarge(Exception):
    """prompt + output can never fit in a worker's KV pool (HTTP 400)."""


class NoWorkers(Exception):
    """No worker is registered with the gateway (HTTP 503)."""


class WorkerError(Exception):
    """A worker was unreachable or answered with an error (HTTP 502)."""
