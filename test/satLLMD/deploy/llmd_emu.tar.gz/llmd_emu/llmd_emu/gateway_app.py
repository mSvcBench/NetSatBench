"""OpenAI-compatible HTTP front-end (the llm-d gateway / inference-scheduler endpoint)."""
from __future__ import annotations

import contextlib
import json
import time
import uuid

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, StreamingResponse

from .config import Config
from .gateway import Gateway, NoWorkers, RequestTooLarge, Timing, WorkerError


_IN_USAGE = {"prompt_tokens", "completion_tokens", "cached_tokens"}   # reported in `usage`, not repeated in `llmd_emu`


def _timing_dict(t: Timing) -> dict:
    return {k: (round(v, 6) if isinstance(v, float) else v) for k, v in t.__dict__.items() if k not in _IN_USAGE}


def _http_error(e: Exception) -> HTTPException:
    if isinstance(e, RequestTooLarge):
        return HTTPException(400, str(e))
    if isinstance(e, NoWorkers):
        return HTTPException(503, str(e))
    return HTTPException(502, str(e))


_UPSTREAM_ERRORS = (RequestTooLarge, NoWorkers, WorkerError)


def create_gateway_app(cfg: Config | None = None, router_url: str = "http://127.0.0.1:8100",
                       transport: httpx.AsyncBaseTransport | None = None, name: str = "gateway-0") -> FastAPI:
    """The gateway, identified by `name` in the responses. It asks the router at `router_url` where to send each request;
    `transport` replaces real HTTP (tests)."""
    cfg = cfg or Config()
    gateway = Gateway(cfg, router_url, transport, name)

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        await gateway.start()
        yield
        await gateway.stop()

    app = FastAPI(title="llm-d emulator", lifespan=lifespan)
    app.state.gateway = gateway

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/v1/models")
    async def models():
        return {"object": "list", "data": [{"id": cfg.model, "object": "model", "owned_by": "llmd-emu"}]}

    @app.get("/debug/state")
    async def state():
        return await gateway.snapshot()

    @app.get("/metrics")
    async def metrics():
        s = await gateway.snapshot()
        lines = [f"llmd_emu_requests_total {s['requests_done']}",
                 f"llmd_emu_ttft_seconds_avg {s['avg_ttft_s']:.6f}",
                 f"llmd_emu_e2e_seconds_avg {s['avg_e2e_s']:.6f}",
                 f"llmd_emu_cached_token_fraction_avg {s['avg_cached_fraction']:.6f}",
                 f"llmd_emu_workers {len(s['workers'])}"]
        for w in s["workers"]:
            pod = w["name"]
            lines += [f'llmd_emu_gateway_inflight{{pod="{pod}"}} {w["inflight"]}',
                      f'llmd_emu_approx_cache_blocks{{pod="{pod}"}} {w["approx_cache"]["blocks_used"]}']
            st = w["state"]
            if "error" in st:
                continue
            lines += [f'llmd_emu_kv_hit_rate{{pod="{pod}"}} {st["hit_rate"]:.6f}',
                      f'llmd_emu_kv_cached_blocks{{pod="{pod}"}} {st["blocks_used"]}',
                      f'llmd_emu_kv_pinned_blocks{{pod="{pod}"}} {st["kv_pinned_blocks"]}',
                      f'llmd_emu_kv_evictions_total{{pod="{pod}"}} {st["evictions"]}',
                      f'llmd_emu_inflight{{pod="{pod}"}} {st["inflight"]}']
        return PlainTextResponse("\n".join(lines) + "\n")

    @app.get("/reset")
    async def reset():
        """Clear the router's approximate indexes and the workers' prefix caches and counters."""
        await gateway.reset()
        return {"status": "ok"}

    async def _serve(prompt: str, body: dict, chat: bool):
        stream = bool(body.get("stream", False))
        max_tokens = body.get("max_completion_tokens", body.get("max_tokens"))
        rid = ("chatcmpl-" if chat else "cmpl-") + uuid.uuid4().hex[:24]
        created = int(time.time())
        obj = "chat.completion" if chat else "text_completion"
        gen = gateway.run(prompt, max_tokens)

        def usage(t: Timing) -> dict:
            return {"prompt_tokens": t.prompt_tokens, "completion_tokens": t.completion_tokens,
                    "total_tokens": t.prompt_tokens + t.completion_tokens,
                    "prompt_tokens_details": {"cached_tokens": t.cached_tokens}}

        if not stream:
            toks, tm = [], None
            try:
                async for tok, tm in gen:
                    toks.append(tok)
            except _UPSTREAM_ERRORS as e:
                raise _http_error(e)
            text = " ".join(toks)
            choice = ({"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}
                      if chat else {"index": 0, "text": text, "finish_reason": "stop"})
            return JSONResponse({"id": rid, "object": obj, "created": created, "model": cfg.model,
                                 "choices": [choice], "usage": usage(tm), "llmd_emu": _timing_dict(tm)})

        # Streaming: fetch first token before sending headers so errors map to HTTP 400.
        try:
            first = await gen.__anext__()
        except _UPSTREAM_ERRORS as e:
            raise _http_error(e)

        async def sse():
            def chunk(delta_text: str | None, finish: str | None = None, role: bool = False):
                if chat:
                    delta = {"role": "assistant"} if role else ({"content": delta_text} if delta_text is not None else {})
                    ch = {"index": 0, "delta": delta, "finish_reason": finish}
                else:
                    ch = {"index": 0, "text": delta_text or "", "finish_reason": finish}
                return "data: " + json.dumps({"id": rid, "object": obj + (".chunk" if chat else ""), "created": created,
                                              "model": cfg.model, "choices": [ch]}) + "\n\n"
            if chat:
                yield chunk(None, role=True)
            tok, tm = first
            yield chunk(tok)
            async for tok, tm in gen:
                yield chunk(" " + tok)
            yield chunk(None, finish="stop")
            final = {"id": rid, "object": obj, "created": created, "model": cfg.model, "choices": [],
                     "usage": usage(tm), "llmd_emu": _timing_dict(tm)}
            yield "data: " + json.dumps(final) + "\n\n"
            yield "data: [DONE]\n\n"
        return StreamingResponse(sse(), media_type="text/event-stream")

    @app.post("/v1/chat/completions")
    async def chat(req: Request):
        body = await req.json()
        msgs = body.get("messages")
        if not isinstance(msgs, list) or not msgs:
            raise HTTPException(400, "'messages' must be a non-empty list")
        # Content only: a "role:" prefix would add 2 tokens per message with the toy tokenizer.
        prompt = "\n".join(str(m.get("content", "")) for m in msgs)
        return await _serve(prompt, body, chat=True)

    @app.post("/v1/completions")
    async def completions(req: Request):
        body = await req.json()
        prompt = body.get("prompt")
        if isinstance(prompt, list):
            prompt = "\n".join(map(str, prompt))
        if not isinstance(prompt, str):
            raise HTTPException(400, "'prompt' must be a string")
        return await _serve(prompt, body, chat=False)

    return app
