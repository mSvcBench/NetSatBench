"""HTTP front-end of the router (the llm-d inference scheduler). Workers register here; the gateway asks it (POST /pick) which
worker to forward each request to. The router only picks: it periodically reads each worker's load from the worker and keeps its
approximate prefix index from its own picks."""
from __future__ import annotations

import asyncio
import contextlib
import logging

import httpx
from fastapi import FastAPI, HTTPException, Request

from .config import Config
from .errors import NoWorkers
from .router import Router, WorkerHandle

log = logging.getLogger("llmd_emu.router")


def create_router_app(cfg: Config | None = None, transport: httpx.AsyncBaseTransport | None = None,
                      name: str = "router-0") -> FastAPI:
    """The router, identified by `name` in its answers. Workers join the pool by POSTing to /register; `transport`
    replaces real HTTP to the workers (tests)."""
    cfg = cfg or Config()
    router = Router(cfg)
    client = httpx.AsyncClient(transport=transport, timeout=None)

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        task = asyncio.create_task(refresh_loop())
        yield
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await client.aclose()

    app = FastAPI(title="llm-d emulator router", lifespan=lifespan)
    app.state.router = router

    async def body_of(req: Request) -> dict:
        body = await req.json()
        if not isinstance(body, dict):
            raise HTTPException(422, "JSON object expected")
        return body

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/register")
    async def register(req: Request):
        body = await body_of(req)
        try:
            w = router.register(body["name"], body["url"], int(body["kv_cache_blocks"]), int(body["block_size"]),
                                int(body["slots"]))
        except (KeyError, TypeError, ValueError):
            raise HTTPException(422, "need name, url, kv_cache_blocks, block_size, slots")
        return {"status": "ok", "workers": sorted(router.workers), "registered": w.name}

    @app.post("/deregister")
    async def deregister(req: Request):
        body = await body_of(req)
        return {"status": "ok", "removed": router.deregister(body.get("name", ""))}

    async def refresh(w: WorkerHandle) -> None:
        """Rebase the worker's inflight on its own count (like the endpoint picker scraping model-server metrics);
        drop it if unreachable."""
        try:
            st = (await client.get(f"{w.url}/debug/state", timeout=5)).json()
        except httpx.HTTPError as e:
            log.debug("worker=%s unreachable, dropped from pool: %r", w.name, e)
            router.deregister(w.name)
            return
        w.completed = st["completed"]
        w.inflight = st["inflight"]

    async def refresh_loop() -> None:
        while True:
            await asyncio.sleep(cfg.router.refresh_interval_s)
            await asyncio.gather(*(refresh(w) for w in list(router.workers.values())))

    @app.post("/pick")
    async def pick(req: Request):
        """Body: {"prompt": str, "n_out": int}. Returns the worker the gateway must forward the request to.
        The router assumes that worker will now cache the prompt (it may evict it later)."""
        body = await body_of(req)
        prompt, n_out = body.get("prompt"), body.get("n_out")
        if not isinstance(prompt, str) or not isinstance(n_out, int):
            raise HTTPException(422, "'prompt' (str) and 'n_out' (int) are required")
        try:
            w, hashes = router.pick(prompt, n_out)
        except NoWorkers as e:
            raise HTTPException(503, str(e))
        w.approx.insert(hashes)
        w.inflight += 1     # until the next refresh rebases it on the worker's own count
        return {"router": name, "worker": w.name, "url": w.url, "inflight": w.inflight}

    @app.post("/reset")
    async def reset():
        """Clear the approximate indexes here, and the real caches and counters on every worker."""
        router.reset()

        async def reset_worker(w: WorkerHandle):
            try:
                await client.post(f"{w.url}/reset", timeout=5)
            except httpx.HTTPError:
                pass
        await asyncio.gather(*(reset_worker(w) for w in list(router.workers.values())))
        return {"status": "ok"}

    @app.get("/debug/state")
    async def state():
        """Per worker: the router's own view and the worker's real state."""
        async def worker_state(w: WorkerHandle) -> dict:
            try:
                return (await client.get(f"{w.url}/debug/state", timeout=5)).json()
            except httpx.HTTPError as e:
                return {"error": repr(e)}
        handles = list(router.workers.values())
        states = await asyncio.gather(*(worker_state(w) for w in handles))
        return {"name": name, "policy": cfg.router.policy,
                "workers": [{"name": w.name, "url": w.url, "inflight": w.inflight, "completed": w.completed,
                             "approx_cache": w.approx.stats(), "state": st} for w, st in zip(handles, states)]}

    return app
