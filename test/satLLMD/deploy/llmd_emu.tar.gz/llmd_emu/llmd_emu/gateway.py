"""Request pipeline of the gateway: ask the router (HTTP) for a worker -> HTTP to that worker (tokenize -> prefill -> decode there)."""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass
from typing import AsyncIterator

import httpx

from .config import Config
from .errors import NoWorkers, RequestTooLarge, WorkerError

log = logging.getLogger("llmd_emu.gateway")


__all__ = ["Gateway", "Timing", "RequestTooLarge", "NoWorkers", "WorkerError"]


@dataclass
class Timing:
    gateway: str = ""          # ids of the agents that handled the request
    router: str = ""
    pod: str = ""              # the worker's id
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    queue_s: float = 0.0
    prefill_s: float = 0.0
    ttft_s: float = 0.0        # simulated: queue + prefill + decode ttft extra + 1st token
    decode_s: float = 0.0      # decode ttft extra + sum of the token steps
    e2e_s: float = 0.0         # end-to-end latency
    req_arrival_time: float = 0.0 # event-loop clock (loop.time(), monotonic, arbitrary origin) when the request arrived at the gateway


class Gateway:
    def __init__(self, cfg: Config, router_url: str, transport: httpx.AsyncBaseTransport | None = None,
                 name: str = "gateway-0"):
        self.name = name
        self.cfg = cfg
        self.router_url = router_url.rstrip("/")
        self.history: list[Timing] = []
        self._transport = transport
        self.client: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self.client = httpx.AsyncClient(transport=self._transport, timeout=None)

    async def stop(self) -> None:
        if self.client:
            await self.client.aclose()

    async def _router(self, path: str, body: dict | None = None, method: str = "POST") -> httpx.Response:
        try:
            return await self.client.request(method, f"{self.router_url}{path}", json=body, timeout=10)
        except httpx.HTTPError as e:
            raise WorkerError(f"router unreachable: {e!r}") from e

    async def _pick(self, prompt: str, n_out: int) -> dict:
        r = await self._router("/pick", {"prompt": prompt, "n_out": n_out})
        if r.status_code == 503:
            raise NoWorkers(r.json().get("detail", "no worker registered"))
        if r.status_code != 200:
            raise WorkerError(f"router answered HTTP {r.status_code}")
        return r.json()

    async def run(self, prompt: str, max_tokens: int | None) -> AsyncIterator[tuple[str | None, Timing]]:
        """Yield (token, timing) for each generated token; timing is the same mutable object,
        fully populated once the generator is exhausted."""
        n_out = max_tokens if max_tokens is not None else self.cfg.default_output_tokens
        n_out = max(1, n_out)
        tm = Timing(completion_tokens=n_out)
        tm.req_arrival_time = asyncio.get_running_loop().time()

        request_id = uuid.uuid4().hex[:8] # request ID for logging and tracing
        try:
            pick = await self._pick(prompt, n_out)  # endpoint worker from the router
        except (NoWorkers, WorkerError) as e:
            log.debug("req=%s route_failed error=%s", request_id, e)
            raise
        worker_name, worker_url = pick["worker"], pick["url"]
        tm.pod = worker_name
        tm.gateway, tm.router = self.name, pick["router"]
        
        log.debug("req=%s routed router=%s worker=%s policy=%s inflight=%d max_tokens=%d",
                  request_id, tm.router, worker_name, self.cfg.router.policy, pick["inflight"], n_out)
        try:
            async with self.client.stream("POST", f"{worker_url}/generate", json={"prompt": prompt, "n_out": n_out, "req_id": request_id}) as r:
                if r.status_code != 200:
                    log.debug("req=%s worker=%s http_status=%d", request_id, worker_name, r.status_code)
                if r.status_code == 400:
                    raise RequestTooLarge(json.loads(await r.aread()).get("detail", "request too large"))
                if r.status_code != 200:
                    raise WorkerError(f"{worker_name} answered HTTP {r.status_code}")
                async for line in r.aiter_lines():
                    if not line:
                        continue
                    msg = json.loads(line)
                    if msg.get("done"):               # last line: the worker's timings for the whole request
                        for k in ("queue_s", "prefill_s", "decode_s", "e2e_s", "ttft_s", "prompt_tokens", "cached_tokens"):
                            setattr(tm, k, msg[k])
                        continue
                    yield msg["token"], tm
        except httpx.HTTPError as e:
            log.debug("req=%s worker=%s unreachable: %r", request_id, worker_name, e)
            raise WorkerError(f"{worker_name} unreachable: {e!r}") from e
        log.debug("req=%s done worker=%s prompt_tokens=%d cached_tokens=%d completion_tokens=%d queue_s=%.6f "
                  "prefill_s=%.6f decode_s=%.6f ttft_s=%.6f e2e_s=%.6f",
                  request_id, tm.pod, tm.prompt_tokens, tm.cached_tokens, tm.completion_tokens,
                  tm.queue_s, tm.prefill_s, tm.decode_s, tm.ttft_s, tm.e2e_s)
        self.history.append(tm)
        del self.history[:-1000]

    async def reset(self) -> None:
        """Clear the stats here and ask the router to clear its indexes and the workers' caches and stats."""
        self.history.clear()
        await self._router("/reset")

    async def snapshot(self) -> dict:
        """Gateway stats plus, per worker, the router's view and the worker's real state."""
        h = self.history
        avg = lambda xs: (sum(xs) / len(xs)) if xs else 0.0
        workers = (await self._router("/debug/state", method="GET")).json()["workers"]
        return {
            "name": self.name,
            "requests_done": len(h),
            "avg_ttft_s": avg([t.ttft_s for t in h]),
            "avg_e2e_s": avg([t.e2e_s for t in h]),
            "avg_cached_fraction": avg([t.cached_tokens / t.prompt_tokens for t in h if t.prompt_tokens]),
            "workers": workers,
        }
