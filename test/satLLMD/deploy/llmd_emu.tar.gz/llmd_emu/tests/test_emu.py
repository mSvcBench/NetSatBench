import contextlib
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from llmd_emu import Config, create_gateway_app, create_router_app, create_worker_app
from llmd_emu.kvcache import PrefixKVCache, block_hashes, tokenize


def fast_cfg(**kw):
    c = Config(time_scale=1000.0)
    for k, v in kw.items():
        setattr(c, k, v)
    return c


class AppsTransport(httpx.AsyncBaseTransport):
    """Routes gateway/router -> router/worker HTTP calls to in-process apps by host name (no sockets)."""

    def __init__(self, apps):
        self._t = {host: httpx.ASGITransport(app=a) for host, a in apps.items()}

    async def handle_async_request(self, request):
        return await self._t[request.url.host].handle_async_request(request)


@contextlib.contextmanager
def cluster(cfg=None, register=True):
    """Gateway TestClient (`cl.router` is the router's) + `cfg.worker.replicas` worker apps reachable at http://w<i>;
    yields (client, workers)."""
    cfg = cfg or fast_cfg()
    apps = {f"w{i}": create_worker_app(cfg, f"worker-{i}") for i in range(cfg.worker.replicas)}
    router = create_router_app(cfg, transport=AppsTransport(apps))
    gateway = create_gateway_app(cfg, "http://router", transport=AppsTransport({**apps, "router": router}))
    with TestClient(router) as rc, TestClient(gateway) as cl:
        cl.router = rc
        if register:
            for host, a in apps.items():
                assert rc.post("/register", json=a.state.worker.registration(f"http://{host}")).status_code == 200
        yield cl, [a.state.worker for a in apps.values()]


LONG = " ".join(f"w{i}" for i in range(100))


def chat(client, content, **kw):
    return client.post("/v1/chat/completions", json={"messages": [{"role": "user", "content": content}], **kw})


def test_prefix_property_and_lru():
    a = block_hashes(tokenize(LONG), 16)
    b = block_hashes(tokenize(LONG + " extra tail"), 16)
    assert a == b[:len(a)]
    c = PrefixKVCache(2)
    c.insert(a[:3])
    assert len(c) == 2 and c.evictions == 1 and c.peek(a[:3]) == 0  # first block evicted -> no prefix


def test_timing_formula_and_cache_hit():
    cfg = fast_cfg()
    cfg.worker.replicas = 1
    with cluster(cfg) as (cl, _):
        r1 = chat(cl, LONG, max_tokens=10).json()
        r2 = chat(cl, LONG, max_tokens=10).json()
    e1, e2 = r1["llmd_emu"], r2["llmd_emu"]
    p = cfg.prefill
    u1, u2 = r1["usage"], r2["usage"]
    assert u1["prompt_tokens_details"]["cached_tokens"] == 0
    assert e1["prefill_s"] == pytest.approx(p.base_s + u1["prompt_tokens"] * p.per_token_s, rel=1e-3)
    assert u2["prompt_tokens_details"]["cached_tokens"] > 0 and e2["prefill_s"] < e1["prefill_s"]
    assert e1["decode_s"] >= 10 * cfg.decode.per_token_s
    assert len(r1["choices"][0]["message"]["content"].split()) >= 10


def test_prefix_aware_routing_sticks_to_pod():
    with cluster() as (cl, _):
        pods = {chat(cl, LONG, max_tokens=2).json()["llmd_emu"]["pod"] for _ in range(4)}
    assert len(pods) == 1


def test_streaming():
    with cluster() as (cl, _):
        r = chat(cl, "hello there", max_tokens=5, stream=True)
        events = [l[6:] for l in r.text.splitlines() if l.startswith("data: ")]
    assert events[-1] == "[DONE]"
    assert json.loads(events[-2])["usage"]["completion_tokens"] == 5


def test_too_large_rejected():
    cfg = fast_cfg()
    cfg.worker.kv_cache_blocks = 2
    with cluster(cfg) as (cl, _):
        assert chat(cl, LONG, max_tokens=5).status_code == 400


def test_generated_blocks_are_reused_and_reset_clears():
    cfg = fast_cfg()
    cfg.worker.replicas = 1
    with cluster(cfg) as (cl, workers):
        msgs = [{"role": "user", "content": LONG}]
        r1 = cl.post("/v1/chat/completions", json={"messages": msgs, "max_tokens": 40}).json()
        answer = r1["choices"][0]["message"]["content"]
        assert len(answer.split()) == 40 and set(answer.split()) <= set(cfg.vocabulary)
        msgs += [{"role": "assistant", "content": answer}, {"role": "user", "content": "next"}]
        r2 = cl.post("/v1/chat/completions", json={"messages": msgs, "max_tokens": 4}).json()
        # 100 prompt tokens alone would cache 96; the generated blocks extend it to 128 of the 141 tokens
        assert r2["usage"]["prompt_tokens_details"]["cached_tokens"] == 128
        assert cl.get("/reset").json() == {"status": "ok"}
        assert workers[0].cache.stats()["blocks_used"] == 0
        assert cl.router.app.state.router.workers["worker-0"].approx.stats()["blocks_used"] == 0


def test_reused_blocks_are_not_double_counted():
    cfg = fast_cfg()
    cfg.worker.replicas = 1
    cfg.vocabulary = ["ok"]                  # one-word vocabulary: the answer is the same every time
    cfg.worker.kv_cache_blocks = 20          # 100 prompt + 20 out tokens = 8 blocks per request
    with cluster(cfg) as (cl, (w,)):
        for _ in range(3):
            chat(cl, LONG, max_tokens=20)
            assert w.pinned_blocks == 0
            assert len(w.cache) == 7             # 120 tokens -> 7 full blocks, same blocks every time (no duplicates)
        assert w.cache.stats()["hit_blocks"] == 12   # requests 2 and 3 reuse the 6 prompt blocks


def test_pinned_prompt_blocks_are_shared_by_running_sequences():
    import asyncio
    from llmd_emu.workers import Worker

    cfg = Config()
    cfg.vocabulary = ["ok"]                    # deterministic answer, so repeated requests share generated blocks
    cfg.worker.kv_cache_blocks = 12            # a 100+20 token request needs 8 blocks: 2 of them would not fit unshared
    cfg.prefill.base_s, cfg.prefill.per_token_s, cfg.decode.per_token_s = 0.01, 0.0, 0.02

    async def go():
        w = Worker("w", cfg)

        async def one():
            infos = [info async for _, info in w.run(LONG, 20) if info]
            return infos[0]

        t1 = asyncio.create_task(one())
        await asyncio.sleep(0.1)               # r1 finished prefill and is decoding: its prompt blocks are pinned + shared
        assert w.pinned_blocks == 8 and len(w.cache) == 8
        i2 = await one()
        i1 = await t1
        return w, i1, i2

    w, i1, i2 = asyncio.run(go())
    assert i1["cached_tokens"] == 0 and i2["cached_tokens"] == 96
    assert i2["queue_s"] < 0.05                # admitted at once: only 2 new blocks needed (8 + 2 <= 12)
    assert w.pinned_blocks == 0 and w.cache.pinned_blocks == 0 and len(w.cache) == 7


def test_concurrent_identical_prompts_free_duplicate_blocks():
    import asyncio
    from llmd_emu.workers import Worker

    cfg = Config()
    cfg.vocabulary = ["ok"]                    # deterministic answer, so both sequences generate identical blocks
    cfg.prefill.base_s, cfg.prefill.per_token_s, cfg.decode.per_token_s = 0.01, 0.0, 0.02

    async def go():
        w = Worker("w", cfg)

        async def one():
            return [i async for _, i in w.run(LONG, 20) if i][0]

        t = [asyncio.create_task(one()) for _ in range(2)]   # both start together: neither reuses the other
        await asyncio.sleep(0.1)                              # both finished prefill, still decoding
        mid = (w.pinned_blocks, len(w.cache))
        await asyncio.gather(*t)
        return w, mid

    w, mid = asyncio.run(go())
    assert mid == (10, 10)                  # 6 shared prompt blocks + 2 private each, not 16
    assert w.pinned_blocks == 0 and len(w.cache) == 7


def test_generated_block_is_hashed_and_shared_when_full():
    import asyncio
    from llmd_emu.kvcache import block_hashes, tokenize
    from llmd_emu.workers import Worker

    cfg = Config()
    cfg.prefill.base_s, cfg.prefill.per_token_s, cfg.decode.per_token_s = 0.01, 0.0, 0.02

    async def go():
        w = Worker("w", cfg)
        fixed = w.make_answer(40)
        w.make_answer = lambda n: fixed        # run() must generate the answer we hash below
        full = block_hashes(tokenize(LONG) + w.make_answer(40), cfg.block_size)   # 140 tokens -> 8 full blocks
        task = asyncio.create_task(anext_all(w))
        await asyncio.sleep(0.1)               # ~4 tokens generated: 104 tokens, block 6 (tokens 96-111) not full yet
        before = (full[6] in w.cache, w.pinned_blocks)
        await asyncio.sleep(0.3)               # ~20 tokens: 120 tokens, block 6 full -> hashed and still pinned
        after = (full[6] in w.cache, w.cache.is_pinned(full[6]), w.pinned_blocks)
        await task
        return before, after, w, full

    async def anext_all(w):
        async for _ in w.run(LONG, 40):
            pass

    before, after, w, full = asyncio.run(go())
    assert before == (False, 9)
    assert after == (True, True, 9)            # promoted in place: same memory, now shareable
    assert w.pinned_blocks == 0 and all(h in w.cache for h in full)   # all 8 full blocks cached afterwards


def test_workers_register_and_deregister():
    with cluster(register=False) as (cl, workers):
        assert chat(cl, "hi", max_tokens=2).status_code == 503            # empty pool
        w0 = workers[0]
        r = cl.router.post("/register", json=w0.registration("http://w0")).json()
        assert r["workers"] == ["worker-0"]
        assert chat(cl, "hi", max_tokens=2).json()["llmd_emu"]["pod"] == "worker-0"
        assert cl.router.post("/deregister", json={"name": "worker-0"}).json()["removed"] is True
        assert chat(cl, "hi", max_tokens=2).status_code == 503
        assert cl.router.post("/register", json={"name": "x"}).status_code == 422


def test_gateway_keeps_approximate_view_of_worker_cache():
    cfg = fast_cfg()
    cfg.worker.kv_cache_blocks = 64
    with cluster(cfg) as (cl, workers):
        pod = chat(cl, LONG, max_tokens=4).json()["llmd_emu"]["pod"]
        handle = cl.router.app.state.router.workers[pod]
        real = next(w for w in workers if w.name == pod)
        hashes = block_hashes(tokenize(LONG), cfg.block_size)
        assert handle.approx.capacity == real.capacity == 64        # same size as the worker's KV pool
        assert handle.approx.peek(hashes) == len(hashes) == 6      # prompt hashes recorded when routed
        # the real cache evicts on its own; the gateway's view does not notice
        real.cache.clear()
        assert real.cache.peek(hashes) == 0 and handle.approx.peek(hashes) == 6
        # ...and still routes by it
        assert chat(cl, LONG, max_tokens=2).json()["llmd_emu"]["pod"] == pod


def test_debug_state_and_metrics_combine_gateway_and_worker_views():
    with cluster() as (cl, _):
        chat(cl, LONG, max_tokens=2)
        st = cl.get("/debug/state").json()
        assert {w["name"] for w in st["workers"]} == {"worker-0", "worker-1"}
        assert all("approx_cache" in w and "kv_capacity_blocks" in w["state"] for w in st["workers"])
        m = cl.get("/metrics").text
        assert "llmd_emu_workers 2" in m and 'llmd_emu_kv_hit_rate{pod="worker-0"}' in m


def test_steps_slow_down_with_concurrent_sequences():
    import asyncio
    from llmd_emu.workers import Worker

    cfg = Config()
    cfg.prefill.base_s, cfg.prefill.per_token_s, cfg.prefill.load_factor = 0.01, 0.0, 1.0
    cfg.decode.per_token_s, cfg.decode.load_factor = 0.02, 0.5

    async def one(w):
        return [i async for _, i in w.run(LONG, 3)]

    async def go():
        alone = await one(Worker("a", cfg))
        w = Worker("b", cfg)
        both = await asyncio.gather(one(w), one(w))
        return alone, both

    alone, both = asyncio.run(go())
    assert alone[0]["prefill_s"] == pytest.approx(0.01) and alone[0]["step_s"] == pytest.approx(0.02)
    # the 2nd sequence starts its prefill with 1 other running: prefill x2; both decode with 2 running: x1.5
    assert both[0][0]["prefill_s"] == pytest.approx(0.01) and both[1][0]["prefill_s"] == pytest.approx(0.02)
    assert all(i["step_s"] == pytest.approx(0.03) for seqs in both for i in seqs)
    assert both[1][0]["ttft_s"] > alone[0]["ttft_s"]


def test_decode_s_is_the_sum_of_actual_steps():
    cfg = fast_cfg()
    cfg.worker.replicas = 1
    cfg.decode.load_factor = 1.0
    with cluster(cfg) as (cl, _):
        e = chat(cl, "hello world", max_tokens=5).json()["llmd_emu"]
    assert e["decode_s"] == pytest.approx(cfg.decode.ttft_s + 5 * cfg.decode.per_token_s)   # alone: no slowdown


def test_worker_answer_info_only_when_verbose():
    cfg = fast_cfg()
    for verbose in (False, True):
        with TestClient(create_worker_app(cfg, "worker-0", verbose_answer=verbose)) as c:
            lines = [json.loads(l) for l in c.post("/generate", json={"prompt": "hello world", "n_out": 3}).text.splitlines()]
        toks, done = lines[:-1], lines[-1]
        assert len(toks) == 3 and all(("info" in l) == verbose for l in toks)
        assert done["done"] and {"queue_s", "prefill_s", "decode_s", "e2e_s"} <= set(done)


def test_response_names_the_agents_involved():
    cfg = fast_cfg()
    cfg.worker.replicas = 1
    apps = {"w0": create_worker_app(cfg, "worker-A")}
    router = create_router_app(cfg, transport=AppsTransport(apps), name="router-X")
    gateway = create_gateway_app(cfg, "http://router", transport=AppsTransport({**apps, "router": router}), name="gateway-Y")
    with TestClient(router) as rc, TestClient(gateway) as cl:
        assert rc.post("/register", json=apps["w0"].state.worker.registration("http://w0")).status_code == 200
        e = chat(cl, "hello world", max_tokens=2).json()["llmd_emu"]
    assert (e["gateway"], e["router"], e["pod"]) == ("gateway-Y", "router-X", "worker-A")
